import { useEffect, useMemo, useState } from "react";
import type { FormEvent } from "react";
import type { LucideIcon } from "lucide-react";
import {
  ArrowDownRight,
  ArrowUpRight,
  Check,
  ChevronRight,
  Clock3,
  Droplets,
  Hammer,
  Leaf,
  Menu,
  MessageCircle,
  Phone,
  Quote,
  ShieldCheck,
  Sparkles,
  Star,
  Truck,
  UserRound,
  WashingMachine,
  X,
} from "lucide-react";

const PHONE = "+447448817270";
const DISPLAY_PHONE = "07448 817 270";
const WHATSAPP = "https://wa.me/447448817270";

const navItems = [
  ["Services", "services"],
  ["Car valeting", "valeting"],
  ["Results", "results"],
  ["About", "about"],
  ["Contact", "contact"],
] as const;

const heroImage = "/manus-storage/go-fast-hero-van_410215c9.jpg";
const detailImage = "/manus-storage/go-fast-car-detail_56626746.jpg";
const resultCar = "/manus-storage/go-fast-results-car_fd3849a9.jpg";
const resultHome = "/manus-storage/go-fast-results-home_301d2767.jpg";
const windowResult = "/manus-storage/go-fast-window-front-before-after_cd2fd0ee.jpg";
const gardenResult = "/manus-storage/go-fast-garden-front-before-after_16b829cc.jpg";
const drivewayResult = "/manus-storage/go-fast-driveway-white-car-before-after_46089b8a.jpg";
const drivewayNoCarResult = "/manus-storage/go-fast-driveway-no-car-before-after_61dadea2.png";
const kitchenResult = "/manus-storage/go-fast-kitchen-cleaning-before-after_48e53ac1.jpg";
const recoveryResult = "/manus-storage/go-fast-recovery-countryside-before-after_ff859ceb.jpg";
const golfResult = "/manus-storage/go-fast-golf-gtr-driveway-before-after_3a8ebb17.jpg";
const livingResult = "/manus-storage/go-fast-living-room-removals-before-after_31999115.jpg";
const storageResult = "/manus-storage/go-fast-storage-removals-before-after_b7654922.jpg";
const secondRecoveryResult = "/manus-storage/go-fast-recovery-second-tow-before-after_68918ba6.jpg";
const secondKitchenResult = "/manus-storage/go-fast-kitchen-cleaning-second-before-after_017e9899.jpg";
const secondGardenResult = "/manus-storage/go-fast-gardening-second-before-after_d4cf3e87.jpg";
const largeDrivewayResult = "/manus-storage/go-fast-large-driveway-pressure-wash-before-after_b63cc12b.jpg";
const secondValetingResult = "/manus-storage/go-fast-valeting-second-car-before-after_7c16a7e1.jpg";
const secondWindowResult = "/manus-storage/go-fast-window-cleaning-second-before-after_e70eec57.jpg";
const thirdWindowResult = "/manus-storage/go-fast-window-cleaning-third-before-after_d44e7009.jpg";
const commercialImage = "/manus-storage/go-fast-commercial_4e11dc05.jpg";
const serviceMontage = "/manus-storage/go-fast-all-services-montage-final_96982bfd.mp4";

const serviceCards: { number: string; icon: LucideIcon; title: string; description: string }[] = [
  { number: "01", icon: Truck, title: "Removals & labour", description: "House moves, office clearances and the hands you need to get it done." },
  { number: "02", icon: WashingMachine, title: "Car wash & valeting", description: "A proper reset for your car, from a fast exterior wash to paint correction." },
  { number: "03", icon: Droplets, title: "Pressure washing", description: "Driveways, patios and walls brought back with a deep, careful clean." },
  { number: "04", icon: Sparkles, title: "Window cleaning", description: "Domestic & commercial, streak-free finish, interior & exterior, water-fed pole." },
  { number: "05", icon: Leaf, title: "Gardening", description: "Hedges trimmed, lawns finished and overgrown spaces made usable again." },
  { number: "06", icon: ShieldCheck, title: "Domestic & public cleaning", description: "Homes, communal areas and commercial spaces refreshed with care." },
  { number: "07", icon: Truck, title: "Vehicle recovery & towing", description: "We come to you — 24/7 vehicle recovery, breakdown and towing service across Coventry & the West Midlands." },
  { number: "08", icon: Hammer, title: "General labour", description: "Flexible practical help for the jobs that do not fit neatly in a box." },
];

const clientSlides = [
  ["McDonald's", "Restaurant & hospitality"],
  ["KFC", "Restaurant & hospitality"],
  ["Costco", "Warehouse & retail"],
  ["Wagamama", "Restaurant & hospitality"],
  ["Sainsbury's", "Retail & supermarket"],
  ["Waterways", "Commercial & location work"],
  ["Discord", "Community & digital"],
  ["Five Guys", "Restaurant & hospitality"],
  ["Primark", "Retail & fashion"],
  ["GD Gym", "Fitness & community"],
  ["PureGym", "Fitness & community"],
  ["Chelsea", "Football & community"],
  ["Coventry City", "Football & community"],
  ["Burger King", "Restaurant & hospitality"],
  ["Waitrose", "Retail & supermarket"],
  ["Tesco", "Retail & supermarket"],
  ["DPD", "Warehouse & delivery"],
  ["BP petrol station", "Forecourt & roadside"],
  ["Shell petrol station", "Forecourt & roadside"],
] as const;

const clientImageSet = [commercialImage, resultCar, commercialImage, detailImage, resultHome, commercialImage, heroImage, resultCar, commercialImage, detailImage, commercialImage, heroImage, resultHome, commercialImage, resultCar, detailImage, commercialImage, commercialImage, heroImage];

const resultCards = [
  { title: "Valeting", headline: "Road grime out. Original shine back.", meta: "Full exterior valet", image: golfResult, tone: "pink" },
  { title: "Windows", headline: "Streak-free finish, inside and out.", meta: "Domestic house frontage · water-fed pole", image: windowResult, tone: "cream" },
  { title: "Pressure washing", headline: "Years of moss, cleared in a day.", meta: "Driveway restoration", image: drivewayNoCarResult, tone: "ink" },
  { title: "Car valeting", headline: "A different car, a fresh driveway finish.", meta: "Exterior wash & paint polish", image: secondValetingResult, tone: "cream" },
  { title: "Pressure washing", headline: "Driveway brightened from the ground up.", meta: "Moss and dirt removal", image: drivewayNoCarResult, tone: "pink" },
  { title: "Gardening", headline: "Overgrown to ready for summer.", meta: "Lawn care & hedge trimming", image: gardenResult, tone: "cream" },
  { title: "Domestic & public cleaning", headline: "Fresh, spotless spaces from the first visit.", meta: "Homes, communal areas & public spaces", image: kitchenResult, tone: "ink" },
  { title: "Removals & labour", headline: "A big job made manageable.", meta: "House moves, office clearances & extra hands", image: livingResult, tone: "pink" },
  { title: "Vehicle recovery & towing", headline: "We come to you — 24/7.", meta: "Breakdown recovery & towing", image: recoveryResult, tone: "cream" },
  { title: "Removals & labour", headline: "Boxes out. Storage space clear.", meta: "Storage clear-outs & moving help", image: storageResult, tone: "ink" },
  { title: "Vehicle recovery & towing", headline: "A second recovery, safely handled.", meta: "Breakdown towing & roadside support", image: secondRecoveryResult, tone: "pink" },
  { title: "Domestic cleaning", headline: "A second kitchen, cleaned right through.", meta: "Hob, worktops, sink & floors", image: secondKitchenResult, tone: "cream" },
  { title: "Gardening", headline: "Another garden, neatly finished.", meta: "Lawn, hedge & border care", image: secondGardenResult, tone: "ink" },
  { title: "Pressure washing", headline: "A bigger house and driveway, bright again.", meta: "Large driveway & patio restoration", image: largeDrivewayResult, tone: "pink" },
  { title: "Windows", headline: "Victorian frontage, clear again.", meta: "Residential glass & frames", image: secondWindowResult, tone: "cream" },
  { title: "Windows", headline: "Commercial glass, polished through.", meta: "Entrance glass & commercial windows", image: thirdWindowResult, tone: "ink" },
] as const;

function Brand({ dark = false }: { dark?: boolean }) {
  return (
    <a href="#top" className={`brand ${dark ? "brand-dark" : ""}`} aria-label="GoFast Services Ltd home">
      <img className="brand-logo-image" src="/manus-storage/go-fast-logo_51dc4eb2.png" alt="Go Fast logo" />
      <span className="brand-copy"><strong>GoFast</strong><small>Services Ltd</small></span>
    </a>
  );
}

function SectionHeading({ kicker, title, copy, align = "left" }: { kicker: string; title: React.ReactNode; copy?: string; align?: "left" | "center" }) {
  return (
    <div className={`section-heading ${align === "center" ? "section-heading-center" : ""}`}>
      <span className="kicker">{kicker}</span>
      <h2>{title}</h2>
      {copy && <p>{copy}</p>}
    </div>
  );
}

function LogoFallbackNote() {
  return <span className="sr-only">Go Fast logo mark</span>;
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [clientIndex, setClientIndex] = useState(0);
  const [reelIndex, setReelIndex] = useState(0);
  const [sent, setSent] = useState(false);
  const [lastMessage, setLastMessage] = useState("");

  useEffect(() => {
    const timer = window.setInterval(() => setClientIndex((current) => (current + 1) % clientSlides.length), 5000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    const timer = window.setInterval(() => setReelIndex((current) => (current + 1) % 3), 2000);
    return () => window.clearInterval(timer);
  }, []);

  const currentClient = clientSlides[clientIndex];
  const currentReel = [
    { title: "THE WORK IS IN THE FINISH", sub: "Before. After. Sorted.", tag: "Go Fast / 10 sec reel" },
    { title: "LOCAL HANDS. PROPER RESULTS.", sub: "Cars, homes & businesses — sorted.", tag: "West Midlands / 24·7" },
    { title: "SHOW UP. DO IT PROPERLY.", sub: "A mobile team you can rely on.", tag: "Coventry based / On the move" },
  ][reelIndex];

  const handleQuote = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const name = String(data.get("name") || "").trim();
    const service = String(data.get("service") || "").trim();
    const location = String(data.get("location") || "").trim();
    const details = String(data.get("details") || "").trim() || "Not provided";
    const message = `Hello GoFast Services Ltd, I'd like a quote.\nName: ${name}\nService: ${service}\nLocation: ${location}\nDetails: ${details}`;
    const url = `${WHATSAPP}?text=${encodeURIComponent(message)}`;
    setLastMessage(url);
    setSent(true);
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const openWhatsApp = () => window.open(WHATSAPP, "_blank", "noopener,noreferrer");

  return (
    <div id="top" className="site-shell">
      <div className="top-strip">
        <div className="container top-strip-inner">
          <span><Clock3 size={14} /> Available 24 hours a day, 7 days a week</span>
          <span className="top-strip-locations">Coventry · Birmingham · Solihull · Warwickshire</span>
          <a href={`tel:${PHONE}`}><Phone size={14} /> {DISPLAY_PHONE}</a>
        </div>
      </div>

      <header className="site-header">
        <div className="container header-inner">
          <Brand />
          <nav className={`desktop-nav ${menuOpen ? "mobile-nav-open" : ""}`} aria-label="Main navigation">
            {navItems.map(([label, id]) => <a key={id} href={`#${id}`} onClick={() => setMenuOpen(false)}>{label}</a>)}
            <a className="button button-pink nav-cta" href={WHATSAPP} target="_blank" rel="noreferrer"><MessageCircle size={16} /> Get a quote</a>
          </nav>
          <button className="menu-toggle" type="button" aria-label={menuOpen ? "Close navigation" : "Open navigation"} aria-expanded={menuOpen} onClick={() => setMenuOpen((open) => !open)}>
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </header>

      <main>
        <section className="hero-section">
          <div className="container hero-grid">
            <div className="hero-copy">
              <span className="eyebrow"><span className="eyebrow-dot" /> WE COME TO YOU, 24/7</span>
              <h1>Welcome<span className="pink-dot">.</span></h1>
              <p className="hero-lede">One reliable local team for cars, homes and businesses across the West Midlands.</p>
              <div className="hero-actions">
                <a className="button button-pink" href={WHATSAPP} target="_blank" rel="noreferrer">Get a free quote <ArrowUpRight size={17} /></a>
                <a className="button button-outline" href={`tel:${PHONE}`}><Phone size={16} /> Call {DISPLAY_PHONE}</a>
              </div>
              <div className="trust-row">
                <span><ShieldCheck size={18} /> Fully insured</span>
                <span><Check size={18} /> DBS checked</span>
                <span><span className="trust-pound">£</span> No call-out fee</span>
              </div>
            </div>
            <div className="hero-visual">
              <div className="hero-image-wrap">
                <video className="hero-service-video" src={serviceMontage} autoPlay loop muted playsInline preload="auto" aria-label="GoFast services montage: car valeting, pressure washing, gardening and vehicle recovery" />
                <div className="hero-image-overlay" />
                <div className="floating-card floating-card-top"><strong>1,000+</strong><span>customers served</span></div>
                <div className="floating-card floating-card-bottom"><span className="status-dot" /> <strong>Fast response</strong><small>Coventry based · mobile team</small></div>
              </div>
              <div className="hero-stamp"><span>LOCAL</span><span>TEAM</span><strong>24/7</strong></div>
            </div>
          </div>
          <div className="container location-row"><span>Coventry</span><i /> <span>Birmingham</span><i /> <span>Solihull</span><i /> <span>Leamington Spa</span><i /> <span>Rugby</span><i /> <span>Nuneaton</span><i /> <a href="mailto:GO@gofast.co.uk">GO@gofast.co.uk</a></div>
        </section>

        <section className="reel-section" aria-label="Go Fast promotional reel">
          <div className="container">
            <div className="promo-reel">
              <video className="reel-video" autoPlay loop muted playsInline preload="auto" aria-label="GoFast ten-second service slideshow">
                <source src={serviceMontage} type="video/mp4" />
              </video>
              <div className="reel-noise" />
              <div className="reel-topline"><span>GO FAST / SERVICE FILM</span><span>00:10 <span className="live-dot" /></span></div>
              <div className="reel-content" key={reelIndex}>
                <span className="reel-tag">{currentReel.tag}</span>
                <h2>{currentReel.title}</h2>
                <p>{currentReel.sub}</p>
              </div>
              <div className="reel-swipe">MOBILE SERVICE / WEST MIDLANDS <ArrowDownRight size={18} /></div>
              <div className="reel-progress"><span style={{ width: `${((reelIndex + 1) / 3) * 100}%` }} /></div>
            </div>
          </div>
        </section>

        <section id="services" className="section section-services">
          <div className="container">
            <div className="services-intro">
              <SectionHeading kicker="ONE TEAM. PLENTY SORTED." title={<>Practical help,<br /><em>without the fuss.</em></>} copy="From a clean car to a cleared garage, we make getting things done feel simple. Clear quotes, friendly people and a fast local response." />
              <div className="intro-side-note"><span>01</span><p>One phone number<br />for the jobs that matter.</p></div>
            </div>
            <div className="service-grid">
              {serviceCards.map(({ number, icon: Icon, title, description }) => (
                <article className="service-card" key={number}>
                  <div className="service-card-top"><span className="service-number">{number}</span><Icon size={23} strokeWidth={1.7} /></div>
                  <h3>{title}</h3>
                  <p>{description}</p>
                  <a href="#contact" className="card-action">Explore service <ChevronRight size={16} /></a>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="client-panel-section" aria-label="Trusted local locations">
          <div className="container">
            <div className="client-panel" style={{ backgroundImage: `url(${clientImageSet[clientIndex]})` }}>
              <div className="client-shade" />
              <div className="client-panel-content">
                <span className="client-label">COMMERCIAL & COMMUNITY LOCATIONS</span>
                <h2 key={currentClient[0]}>{currentClient[0]}</h2>
                <p key={currentClient[1]}>{currentClient[1]}</p>
              </div>
              <div className="client-panel-bottom"><span>Commercial & location work</span><span>{String(clientIndex + 1).padStart(2, "0")} / {String(clientSlides.length).padStart(2, "0")}</span></div>
              <div className="client-progress"><span /></div>
            </div>
          </div>
        </section>

        <section id="valeting" className="valeting-section">
          <div className="container valeting-grid">
            <div className="valeting-image"><img src={detailImage} alt="Professional car detailing and paint polishing" /><span className="image-caption">MOBILE VALETING / COVENTRY</span></div>
            <div className="valeting-copy">
              <SectionHeading kicker="NEW SERVICE FOCUS" title={<>Make your car feel<br /><em>brand new.</em></>} copy="A careful, proper clean that goes beyond a quick rinse. Choose the full reset or build the job around what your car needs." />
              <div className="detail-list">
                {["Exterior wash|Bodywork, glass and trim refreshed", "Interior clean|Seats, carpets, dash and touch points", "Wheels & tyres|Deep clean with a dressed finish", "Paint polishing & scratch removal|Bring back gloss and reduce visible marks"].map((item, index) => { const [name, copy] = item.split("|"); return <div className="detail-item" key={name}><span>0{index + 1}</span><div><strong>{name}</strong><p>{copy}</p></div></div>; })}
              </div>
              <a className="button button-pink" href={WHATSAPP} target="_blank" rel="noreferrer">Ask about your car <ArrowUpRight size={17} /></a>
            </div>
          </div>
        </section>

        <section id="results" className="section results-section">
          <div className="container">
            <SectionHeading kicker="THE PROOF IS IN THE FINISH" title={<>Before. After.<br /><em>Sorted.</em></>} copy="Every job gets the same energy: show up, do it properly and leave things better than we found them." />
            <div className="results-grid">
              {resultCards.map((card, index) => (
                <article className={`result-card result-${card.tone}`} key={`${card.title}-${index}`}>
                  <div className="result-image"><img src={card.image} alt={`${card.title} result example`} /><div className="result-labels"><span>BEFORE</span><span>AFTER</span></div></div>
                  <div className="result-copy"><span className="result-type">{card.title}</span><h3>{card.headline}</h3><p>{card.meta}</p></div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="testimonials-section">
          <div className="container">
            <div className="testimonials-header"><SectionHeading kicker="GOOD PEOPLE SAY GOOD THINGS" title={<>Trusted by the<br /><em>neighbourhood.</em></>} /><div className="rating-lockup"><strong>5.0</strong><div><div className="stars">★★★★★</div><small>Customer rating</small></div></div></div>
            <div className="testimonial-grid">
              {[
                ["They arrived when they said they would, gave me a clear price and left the car looking better than it has in years. Properly friendly service.", "Jordan M.", "Car wash & valeting · Coventry"],
                ["Our windows are spotless and the whole booking was easy. A genuinely reliable local team.", "Amira S.", "Windows & glass · Solihull"],
                ["We needed a last-minute office clear-out and Go Fast made it feel completely manageable. Fast, careful and no fuss.", "Rory B.", "Removals & labour · Birmingham"],
              ].map(([quote, name, meta]) => <article className="testimonial-card" key={name}><Quote size={25} className="quote-icon" /><div className="stars">★★★★★</div><p>“{quote}”</p><footer><span className="avatar">{name.charAt(0)}</span><span><strong>{name}</strong><small>{meta}</small></span><Check size={16} className="verified" /></footer></article>)}
            </div>
            <p className="testimonial-footnote"><span /> Real service. Clear communication. No inflated promises.</p>
          </div>
        </section>

        <section id="about" className="about-section">
          <div className="container about-grid">
            <div className="about-marker"><span>WHY</span><strong>GO<br />FAST</strong><ArrowDownRight size={24} /></div>
            <div className="about-copy"><SectionHeading kicker="WHY GO FAST" title={<>Local people.<br /><em>Proper service.</em></>} /><p>You should not have to chase a tradesperson, decode a quote or wait weeks for a simple job.</p><p>Go Fast is built around the opposite: a mobile team that communicates clearly, turns up when we say we will and takes pride in the detail.</p><a className="text-link" href="#contact">Meet the team on WhatsApp <ArrowUpRight size={17} /></a></div>
            <div className="stats-grid"><div><strong>24/7</strong><span>available day & night</span></div><div><strong>01</strong><span>local team to call</span></div><div><strong>£0</strong><span>call-out fee</span></div></div>
          </div>
        </section>

        <section id="contact" className="contact-section">
          <div className="container contact-grid">
            <div className="contact-copy"><span className="kicker kicker-light">READY WHEN YOU ARE</span><h2>Tell us what<br /><em>needs doing.</em></h2><p>Send a few details and we’ll come back with a clear, no-pressure quote.</p><div className="contact-links"><a href={WHATSAPP} target="_blank" rel="noreferrer"><MessageCircle size={18} /> Message on WhatsApp</a><a href="mailto:GO@gofast.co.uk"><ArrowUpRight size={18} /> GO@gofast.co.uk</a><a href={`tel:${PHONE}`}><Phone size={18} /> {DISPLAY_PHONE}</a></div></div>
            <div className="quote-card">
              {sent ? <div className="success-state"><div className="success-icon"><Check size={28} /></div><span className="kicker">MESSAGE RECEIVED.</span><h3>Thanks — we’ll be in touch as soon as possible.</h3><p>For the fastest response, message us on WhatsApp.</p><button type="button" className="button button-dark" onClick={() => lastMessage ? window.open(lastMessage, "_blank", "noopener,noreferrer") : openWhatsApp()}>Open WhatsApp <ArrowUpRight size={17} /></button><button type="button" className="reset-link" onClick={() => setSent(false)}>Send another quote</button></div> : <form onSubmit={handleQuote}><div className="form-header"><span>QUICK QUOTE</span><span><ShieldCheck size={15} /> No pressure</span></div><label>Your name<input name="name" required placeholder="e.g. Alex Morgan" /></label><label>What can we help with?<select name="service" required defaultValue=""><option value="" disabled>Select a service</option><option>Car wash & valeting</option><option>Windows & glass cleaning</option><option>Removals & labour</option><option>Pressure washing</option><option>Gardening</option><option>Vehicle recovery & towing</option><option>Domestic & commercial cleaning</option><option>Floor cleaning</option><option>General labour</option></select></label><label>Your location<input name="location" required placeholder="e.g. Coventry CV1" /></label><label>Tell us a little more <span>(optional)</span><textarea name="details" rows={3} placeholder="Timing, access, what needs doing..."></textarea></label><button type="submit" className="button button-pink button-full">Send to WhatsApp <ArrowUpRight size={17} /></button><small className="form-note">Your details open in a pre-filled WhatsApp message. Nothing is stored here.</small></form>}
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container footer-top"><div><Brand dark /><p>Local service. Proper results.</p></div><div className="footer-callout"><span>Serving Coventry, the West Midlands<br />& Warwickshire.</span><a href={`tel:${PHONE}`}>Call {DISPLAY_PHONE} <ArrowUpRight size={16} /></a></div></div>
        <div className="container footer-bottom"><span>© 2026 GoFast Services Ltd</span><span>Coventry · Birmingham · Solihull · Leamington Spa · Rugby · Nuneaton</span><span><ShieldCheck size={15} /> Fully insured & DBS checked</span></div>
      </footer>

      <a className="floating-whatsapp" href={WHATSAPP} target="_blank" rel="noreferrer" aria-label="Message us on WhatsApp"><MessageCircle size={20} /><span>Message us on WhatsApp</span></a>
      <a className="back-to-top" href="#top" aria-label="Back to top"><ArrowUpRight size={19} /></a>
      <LogoFallbackNote />
    </div>
  );
}
